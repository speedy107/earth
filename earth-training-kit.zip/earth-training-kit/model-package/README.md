# Trained blue/red box detector

YOLO11 nano fine-tuned for 80 epochs on your phone videos. The best checkpoint
is from epoch 70. Classes: 0 = blue_box; 1 = red_box. No sky class is trained.
The detector recognizes appearance; it does not measure physical dimensions.

## Files

- boxes-yolo11n.pt: trained Ultralytics/PyTorch checkpoint.
- boxes-yolo11n.onnx: FP32 ONNX model, fixed 320x320 input, batch 1, opset 17.
- model-spec.json: exact input/output interpretation and postprocessing.
- validation-preview.jpg: predictions on all 8 held-out labeled images.
- metrics.json: metrics, individual predictions, and ONNX verification.
- training-settings.yaml / training-results.csv: training configuration and history.
- predict.py: local inference example.
- requirements-training.txt: actual Python package versions used here.

## Results and limitations

Dataset: 53 visually reviewed images (28 blue, 25 red), sampled from ten
recordings. Training: 45 images. Validation: 8 images, four of each color,
from two recordings excluded entirely from training. No recordings overlap
between splits. Best-model validation mAP50: 99.5%; mAP50-95: 84.9%.
All eight images produced one detection with the correct class at confidence
threshold 0.25; this is a small model-selection set, not a final independent
test or evidence of 99.5% real-world accuracy. Multiple clips share the same
room. Empty scenes, multiple boxes together, and unfamiliar scenes need
additional testing. Strong confidence does not guarantee correctness.

ONNX passed onnx.checker and was executed using ONNX Runtime on all eight
validation inputs. Outputs matched PyTorch with rtol=0.001, atol=0.001;
maximum absolute difference across all raw outputs was approximately 0.00163.
The ONNX file contains raw predictions; it does not include NMS.

## Run on a computer

Install ultralytics==8.3.221 in a Python environment with compatible PyTorch.
From this extracted folder:

    python predict.py path/to/image.jpg
    python predict.py path/to/video.mp4

Annotated outputs are saved to predictions/boxes. Use --output to choose
another directory. The script defaults to CPU and input size 320.

## Android browser use

Use boxes-yolo11n.onnx with ONNX Runtime Web inside an HTTPS camera webpage.
No Android application is required, but this model file alone is not a camera
webpage. Browser integration and actual iQOO phone speed have not been tested.
Read model-spec.json: use RGB float32 divided by 255; letterbox to 320x320
with padding value 114; decode output [1,6,2100] as xywh plus two class scores;
apply confidence filtering and class-aware NMS; undo letterbox scaling/padding.
There is no separate objectness score. Start with confidence 0.25 and IoU 0.45.

## Dataset

The separate yolo11-boxes-dataset.zip contains one images/ folder, one labels/
folder, train.txt, val.txt, data.yaml, and source annotation provenance.
Set data.yaml path to its absolute location after extraction.

"""Run the trained detector on an image, video, folder, or computer webcam."""
import argparse,os
from pathlib import Path
root=Path(__file__).resolve().parent
os.environ.setdefault('YOLO_CONFIG_DIR',str(root/'ultralytics-config'))
import torch
from ultralytics import YOLO
parser=argparse.ArgumentParser()
parser.add_argument('source',help='Image/video path, image folder, or 0 for webcam')
parser.add_argument('--model',default=str(root/'boxes-yolo11n.pt'))
parser.add_argument('--output',default=str(root/'predictions'))
parser.add_argument('--conf',type=float,default=.25)
args=parser.parse_args()
torch.set_num_threads(4)
source=int(args.source) if args.source.isdigit() else args.source
for result in YOLO(args.model).predict(source=source,imgsz=320,conf=args.conf,iou=.45,device='cpu',save=True,stream=True,project=args.output,name='boxes',exist_ok=True):
 print(result.verbose())

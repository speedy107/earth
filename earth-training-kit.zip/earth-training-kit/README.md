# Earth block dataset assessment and next steps

## What was actually inspected

The referenced chat exposed trained-box-model.zip through a local temporary attachment. The requested /mnt/data path is not available on this Windows host. Archive inventory: 13 files; two trained model artifacts; no source image directory, per-image label files, split manifests, or dataset YAML. All 12 SHA256SUMS entries match the extracted bytes. The manifest is an integrity check, not independent proof of the training claims.

Found boxes-yolo11n.pt (5,429,459 bytes) and boxes-yolo11n.onnx (10,439,580 bytes). The PT checkpoint was not deserialized. This environment lacks Torch, ONNX and ONNX Runtime, so graph checks and inference were not repeated. Package metrics report successful ONNX checking and comparison; those results are inherited evidence.

Mapping from model-spec.json: **0 = blue_box; 1 = red_box**. Preserve this ordering. No separate Earth/sky class exists. Calling these Earth blocks is the intended application, not an additional learned semantic category.

Documented model interface: RGB float32 NCHW [1,3,320,320], divide pixels by 255, aspect-preserving letterbox with padding 114. Raw output [1,6,2100]: pixel cx, cy, width, height, blue score, red score. No objectness channel or built-in NMS. Start at confidence 0.25, class-aware NMS IoU 0.45; undo letterboxing afterward. These are package specifications, not independently executed checks.

## Dataset and annotations

README describes a separate **yolo11-boxes-dataset.zip**: images/, labels/, train.txt, val.txt, data.yaml and annotation provenance. Its expected format is YOLO detection: each label row is `class cx cy width height`, coordinates normalized to the original image dimensions. That source dataset is absent here. Image counts, label validity, box tightness, missing objects, class correctness and split leakage cannot be confirmed from the trained archive.

Metadata reports 53 images (28 blue, 25 red), 45 training and 8 validation, sampled from ten recordings. This differs from the approximately 100 images mentioned in the conversation. The package claims two complete recordings were held out; provenance cannot be verified without the dataset.

Supplied metrics: precision 0.9837, recall 1.0, mAP50 0.995, mAP50-95 0.8487. Per-class mAP50-95: blue 0.8952, red 0.8022. Eight validation images/instances, four per class; 80 epochs, reported best epoch 70. These are validation results used for model selection, not an independent final test.

Visual review of validation-preview.jpg: all eight panels show the expected red/blue blocks with broadly plausible enclosing predictions. One blue block is clipped at the image edge. Several predicted rectangles include background. Source annotations are not drawn separately, so this preview cannot establish annotation correctness. Scenes are visually similar indoor views with large nearby single blocks.

**Readiness:** usable candidate for computer-side baseline experiments; annotation audit and further training blocked on the source dataset; field robustness and ESP32-P4 deployment unproven. Test small/distant blocks, both colors together, partial occlusion, clutter, empty scenes, confusing red/blue objects, motion blur and actual robot-camera lighting. Maintain a real, independent test set from new recording sessions, with per-class recall and false positives on empty scenes.

## Use this kit after obtaining the source dataset

1. Extract yolo11-boxes-dataset.zip. Confirm class names in its original data.yaml before adopting this template. If different, resolve the mapping instead of silently relabeling.
2. Install requirements.txt in a dedicated environment. Torch may require a platform-specific installation. The supplied package's complete historical dependency lock is retained in model-package/; this kit uses a minimal dependency list.
3. Run `python validate_dataset.py PATH_TO_DATASET --output audit.json`. It checks decoding, normalized box geometry, class IDs, missing/orphan labels, duplicate rows, manifests, exact-byte cross-split duplicates and filename-inferred clip overlap. It supports the documented images/labels and train.txt/val.txt layout. It deliberately fails on obsolete absolute manifest paths so they can be corrected explicitly. It does not validate data.yaml itself or visually verify labels.
4. Review every image with ground-truth boxes overlaid. Label all visible target blocks. Negative images need empty label files. Use tight rectangles around visible extents, including clipped objects; apply one consistent occlusion policy.
5. Set the absolute dataset root in data.yaml. Run from this kit directory: `yolo train cfg=train.yaml`. Default initialization is pretrained yolo11n.pt for a repeatable baseline. To fine-tune the supplied checkpoint, use `yolo train cfg=train.yaml model=model-package/boxes-yolo11n.pt name=earth-finetune`. Neither command was run here.
6. Compare the real-data baseline against augmentation runs on the same untouched validation split. Choose using per-class precision/recall and localization quality; report final performance once on the independent real test set.

## Synthetic augmentation recipe

Start with YOLO's built-in geometric and modest brightness/saturation augmentation in train.yaml; it transforms boxes together with images. Disable hue and BGR swaps because red versus blue is the target distinction. The settings follow the supplied training recipe; tune only with real held-out validation.

For new synthetic scenes, first obtain real source photographs and accurate foreground masks. A bounding box alone is not a foreground mask: a rectangular crop pastes the old room into the new scene. Prefer masked blocks or a textured 3D block with geometry matching the physical object. Use real training-only arena background photographs and preserve the block's color and markings.

Pilot 2 synthetic variants per real training image, retaining the originals. Vary placement, apparent size to match measured robot-camera target sizes, view angle, lighting and mild motion blur. Include both colors together and partial occlusions. Add real empty backgrounds as negatives; ensure they contain no unlabeled target blocks. This ratio is an experimental starting point, not a measured optimum.

Derive boxes from transformed foreground masks or projected geometry after clipping to the canvas. Keep visible extents consistent with the real annotations; manually review heavily occluded cases. Save normalized YOLO labels for every synthetic image. Generated or edited AI scenes require fresh visual review and labeling; existing boxes must not be assumed to remain valid.

Keep every derivative with its parent training session; never augment validation or test for scoring. Record provenance in augmentation_manifest.csv using the supplied header. Compare baseline vs baseline+synthetic; retain synthetic data only if it improves real-world evaluation. No synthetic images were generated because the source data/masks are missing. The preview collage is not a suitable source dataset.

## ESP32-P4 next step

The FP32 ONNX file is not an ESP-DL deployment artifact. Check operator support, convert/quantize using the ESP-DL/ESP-PPQ toolchain for the selected P4 firmware version, calibrate on representative real camera inputs, remeasure detection quality, then benchmark end-to-end latency and memory on the board. Do not infer FPS from model size or desktop validation.

Sources: https://docs.ultralytics.com/modes/train/ ; https://docs.ultralytics.com/guides/yolo-data-augmentation/ ; https://docs.espressif.com/projects/esp-dl/en/latest/tutorials/how_to_quantize_model.html

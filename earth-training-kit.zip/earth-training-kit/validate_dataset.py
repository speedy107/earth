"""Validate the reported flat YOLO dataset. Does not modify annotations.
Usage: python validate_dataset.py DATASET_ROOT --output audit.json
Dependencies: Pillow. Requires images/, labels/, train.txt and val.txt.
"""
import argparse, collections, hashlib, json, math, re
from pathlib import Path
from PIL import Image

def audit(root):
    root = Path(root).resolve()
    errors, warnings, counts, splits = [], [], {}, {}
    extensions = {'.jpg', '.jpeg', '.png', '.bmp', '.webp'}
    images = sorted(p for p in (root/'images').rglob('*') if p.suffix.lower() in extensions)
    if not images:
        errors.append('No source images found under images/')
    stems = collections.Counter(p.stem for p in images)
    for stem, n in stems.items():
        if n > 1: errors.append(f'Ambiguous image stem: {stem}')
    hashes, classes = {}, collections.Counter()
    for p in images:
        try:
            with Image.open(p) as im:
                im.load()
                if min(im.size) <= 0: raise ValueError('invalid dimensions')
        except Exception as exc:
            errors.append(f'{p.name}: unreadable image: {exc}')
        digest = hashlib.sha256(p.read_bytes()).hexdigest()
        hashes.setdefault(digest, []).append(str(p))
        lab = root/'labels'/p.relative_to(root/'images').with_suffix('.txt')
        if not lab.exists():
            errors.append(f'{p.name}: missing label; empty scenes need an empty label file')
            continue
        rows = lab.read_text(encoding='utf-8-sig').splitlines()
        if not any(r.strip() for r in rows): warnings.append(f'{p.name}: empty annotation; verify negative scene')
        seen = set()
        for i, row in enumerate(rows, 1):
            if not row.strip(): continue
            try:
                fields = row.split()
                if len(fields) != 5: raise ValueError('expected class cx cy width height')
                cls = int(fields[0])
                if cls not in (0, 1): raise ValueError('class must be 0=blue or 1=red')
                x, y, w, h = map(float, fields[1:])
                if not all(math.isfinite(v) for v in (x,y,w,h)): raise ValueError('nonfinite value')
                if not (0 <= x <= 1 and 0 <= y <= 1 and 0 < w <= 1 and 0 < h <= 1): raise ValueError('invalid normalized coordinates')
                if x-w/2 < -1e-6 or y-h/2 < -1e-6 or x+w/2 > 1+1e-6 or y+h/2 > 1+1e-6: raise ValueError('box extends outside image')
                key = (cls,x,y,w,h)
                if key in seen: errors.append(f'{lab.name}:{i}: duplicate annotation')
                seen.add(key)
                classes[cls] += 1
            except ValueError as exc:
                errors.append(f'{lab.name}:{i}: {exc}')
    for lab in (root/'labels').rglob('*.txt'):
        if lab.stem not in stems: errors.append(f'Orphan label: {lab}')
    for split in ('train','val','test'):
        manifest = root/f'{split}.txt'
        if not manifest.exists():
            if split != 'test': errors.append(f'Missing {split}.txt')
            continue
        paths = []
        for row in manifest.read_text(encoding='utf-8-sig').splitlines():
            if not row.strip(): continue
            p = Path(row.strip())
            p = (root/p).resolve() if not p.is_absolute() else p.resolve()
            if p not in images: errors.append(f'{split}: unknown image {p}')
            paths.append(str(p))
        if len(set(paths)) != len(paths): errors.append(f'{split}: duplicate manifest entry')
        if not paths: errors.append(f'{split}: empty split')
        splits[split] = paths
        counts[split] = len(paths)
    keys = list(splits)
    for i, a in enumerate(keys):
        for b in keys[i+1:]:
            if set(splits[a]) & set(splits[b]): errors.append(f'Image overlap between {a} and {b}')
            for group in hashes.values():
                if set(group)&set(splits[a]) and set(group)&set(splits[b]): errors.append(f'Identical image bytes across {a}/{b}: {group}')
            clips = lambda k: {re.sub(r'_frame_.*$', '', Path(p).stem) for p in splits[k] if '_frame_' in Path(p).stem}
            overlap = clips(a)&clips(b)
            if overlap: errors.append(f'Filename-inferred clip overlap {a}/{b}: {sorted(overlap)}')
    assigned = set(p for rows in splits.values() for p in rows)
    unassigned = [str(p) for p in images if str(p) not in assigned]
    if unassigned: warnings.append(f'{len(unassigned)} images are absent from split manifests')
    warnings.append('Numeric checks cannot establish color correctness, tightness, missing objects, or near-duplicate/session leakage. Review box overlays and recording provenance.')
    return dict(images=len(images), boxes_by_class=dict(classes), split_counts=counts, errors=errors, warnings=warnings, unassigned=unassigned, duplicate_byte_groups=[g for g in hashes.values() if len(g)>1])

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('root')
    parser.add_argument('--output', default='audit.json')
    args = parser.parse_args()
    result = audit(args.root)
    Path(args.output).write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps(result, indent=2))
    raise SystemExit(1 if result['errors'] else 0)
